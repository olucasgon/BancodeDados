--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE trabalho;
--
-- Name: trabalho; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE trabalho WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE trabalho OWNER TO postgres;

\connect trabalho

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: car; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.car (
    car_id integer NOT NULL,
    car_tx_model character varying(25),
    car_tx_color character varying(20),
    car_tx_plate character varying(10)
);


ALTER TABLE public.car OWNER TO postgres;

--
-- Name: car_car_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.car_car_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.car_car_id_seq OWNER TO postgres;

--
-- Name: car_car_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.car_car_id_seq OWNED BY public.car.car_id;


--
-- Name: garagem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.garagem (
    gar_cd_id integer NOT NULL,
    fk_car_cd_id integer
);


ALTER TABLE public.garagem OWNER TO postgres;

--
-- Name: garagem_gar_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.garagem_gar_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.garagem_gar_cd_id_seq OWNER TO postgres;

--
-- Name: garagem_gar_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.garagem_gar_cd_id_seq OWNED BY public.garagem.gar_cd_id;


--
-- Name: pessoa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pessoa (
    pes_cd_id integer NOT NULL,
    pes_tx_name character varying(25),
    pes_int_cnh integer,
    fk_car_cd_id integer
);


ALTER TABLE public.pessoa OWNER TO postgres;

--
-- Name: pessoa_pes_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pessoa_pes_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pessoa_pes_cd_id_seq OWNER TO postgres;

--
-- Name: pessoa_pes_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pessoa_pes_cd_id_seq OWNED BY public.pessoa.pes_cd_id;


--
-- Name: car car_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car ALTER COLUMN car_id SET DEFAULT nextval('public.car_car_id_seq'::regclass);


--
-- Name: garagem gar_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garagem ALTER COLUMN gar_cd_id SET DEFAULT nextval('public.garagem_gar_cd_id_seq'::regclass);


--
-- Name: pessoa pes_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa ALTER COLUMN pes_cd_id SET DEFAULT nextval('public.pessoa_pes_cd_id_seq'::regclass);


--
-- Data for Name: car; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.car (car_id, car_tx_model, car_tx_color, car_tx_plate) FROM stdin;
\.
COPY public.car (car_id, car_tx_model, car_tx_color, car_tx_plate) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: garagem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.garagem (gar_cd_id, fk_car_cd_id) FROM stdin;
\.
COPY public.garagem (gar_cd_id, fk_car_cd_id) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: pessoa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pessoa (pes_cd_id, pes_tx_name, pes_int_cnh, fk_car_cd_id) FROM stdin;
\.
COPY public.pessoa (pes_cd_id, pes_tx_name, pes_int_cnh, fk_car_cd_id) FROM '$$PATH$$/3341.dat';

--
-- Name: car_car_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.car_car_id_seq', 5, true);


--
-- Name: garagem_gar_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.garagem_gar_cd_id_seq', 5, true);


--
-- Name: pessoa_pes_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pessoa_pes_cd_id_seq', 8, true);


--
-- Name: car car_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car
    ADD CONSTRAINT car_pkey PRIMARY KEY (car_id);


--
-- Name: garagem garagem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garagem
    ADD CONSTRAINT garagem_pkey PRIMARY KEY (gar_cd_id);


--
-- Name: pessoa pessoa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_pkey PRIMARY KEY (pes_cd_id);


--
-- Name: garagem garagem_fk_car_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garagem
    ADD CONSTRAINT garagem_fk_car_cd_id_fkey FOREIGN KEY (fk_car_cd_id) REFERENCES public.car(car_id);


--
-- Name: pessoa pessoa_fk_car_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_fk_car_cd_id_fkey FOREIGN KEY (fk_car_cd_id) REFERENCES public.car(car_id);


--
-- PostgreSQL database dump complete
--

